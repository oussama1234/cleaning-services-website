<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\BookingController;
use App\Http\Controllers\Api\ContactController;

// Public API routes (no authentication required)
Route::post('/booking', [BookingController::class, 'store']);
Route::post('/contact', [ContactController::class, 'store']);

// Protected routes (example)
Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');
